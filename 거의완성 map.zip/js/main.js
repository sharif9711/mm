// main.js - 애플리케이션 진입점 (DB 연동 버전)

console.log("✅ js/main.js loaded successfully.");

// 애플리케이션 초기화 함수
async function initApp() {
    // 중복 실행 방지
    if (window.isAppInitialized) {
        console.log('ℹ️ Application already initialized.');
        return;
    }
    window.isAppInitialized = true;

    console.log('🚀 Initializing application...');

    try {
        // 1. UI 초기화 (진행바, 토스트 메시지)
        if (typeof createProgressAndToastUI === 'function') {
            createProgressAndToastUI();
            console.log('✅ UI components initialized.');
        }

        // 2. 모달창 내용 로드
        const createModalContainer = document.getElementById('createModal');
        if (createModalContainer && typeof getCreateModalHTML === 'function') {
            createModalContainer.innerHTML = getCreateModalHTML();
            console.log('✅ Create modal content loaded.');
        }

        // 3. 서버에서 프로젝트 목록 로드
        if (typeof loadProjects === 'function') {
            console.log('📡 Loading projects from server...');
            const loadedProjects = await loadProjects();
            
            if (loadedProjects && loadedProjects.length >= 0) {
                console.log(`✅ Loaded ${loadedProjects.length} projects from server.`);
            } else {
                console.warn('⚠️ No projects loaded or error occurred.');
            }
        } else {
            console.error('❌ loadProjects function not found!');
        }

        // 4. 프로젝트 목록 렌더링
        if (typeof renderProjects === 'function') {
            renderProjects();
        } else {
            console.error('❌ renderProjects function not found!');
        }

        // 5. URL 해시 확인 (특정 프로젝트 직접 접근)
        const hash = window.location.hash.substring(1);
        if (hash) {
            const project = projects.find(p => p.id === hash);
            if (project) {
                console.log(`🔗 Opening project from URL hash: ${project.projectName}`);
                
                // 프로젝트 상세 로드
                if (typeof loadProjectDetail === 'function') {
                    currentProject = await loadProjectDetail(project.id);
                    if (currentProject && typeof showProjectDetail === 'function') {
                        showProjectDetail();
                    }
                }
            }
        }

        console.log('✅ Application initialization complete.');

    } catch (error) {
        console.error('❌ Failed to load projects:', error);
        
        // 사용자에게 친화적인 오류 메시지
        if (typeof showToast === 'function') {
            showToast('⚠️ 프로젝트 목록을 불러오지 못했습니다.');
        } else {
            alert('프로젝트 목록을 불러오는데 실패했습니다.\n페이지를 새로고침해주세요.');
        }
    }
}

// DOM이 완전히 로드된 후 앱 초기화 실행
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
} else {
    // 이미 DOM이 로드된 경우 즉시 실행
    initApp();
}

console.log('📄 main.js setup complete.');
