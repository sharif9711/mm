// data.js - 최적화 버전 (변경된 행만 저장)

let projects = [];
let currentProject = null;
let selectedProjectId = null;

// API 기본 URL
const API_BASE_URL = '/map/api';

// ✅ 변경된 행 추적
let changedRows = new Set(); // data_id 저장

// 500행 초기 데이터 생성
function createInitialData() {
    const initialData = [];
    for (let i = 0; i < 1500; i++) {
        initialData.push({
            id: Date.now() + '_' + i,
            순번: i + 1,
            이름: '',
            연락처: '',
            주소: '',
            우편번호: '',
            lat: null,
            lng: null,
            vworld_lon: null,
            vworld_lat: null,
            상태: '예정',
            법정동코드: '',
            pnu코드: '',
            대장구분: '',
            본번: '',
            부번: '',
            지목: '',
            면적: '',
            기록사항: '',
            메모: []
        });
    }
    return initialData;
}

// ========== API 통신 함수들 ==========

// 프로젝트 목록 로드
async function loadProjects() {
    try {
        const response = await fetch(`${API_BASE_URL}/project_api.php?action=list`);
        const result = await response.json();
        
        if (result.success) {
            projects = result.projects;
            return projects;
        } else {
            console.error('프로젝트 로드 실패:', result.message);
            showToast('⚠️ ' + result.message);
            return [];
        }
    } catch (error) {
        console.error('프로젝트 로드 오류:', error);
        showToast('⚠️ 서버 연결에 실패했습니다.');
        return [];
    }
}

// 프로젝트 생성
async function createProjectData(name, mapType) {
    try {
        const response = await fetch(`${API_BASE_URL}/project_api.php?action=create`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                projectName: name,
                mapType: mapType || 'vworld'
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showToast('✅ 프로젝트가 생성되었습니다.');
            await loadProjects();
            return result.projectId;
        } else {
            showToast('⚠️ ' + result.message);
            return null;
        }
    } catch (error) {
        console.error('프로젝트 생성 오류:', error);
        showToast('⚠️ 프로젝트 생성에 실패했습니다.');
        return null;
    }
}

// 프로젝트 상세 로드
async function loadProjectDetail(projectId) {
    try {
        showProgress();
        
        const response = await fetch(`${API_BASE_URL}/project_api.php?action=get&pj_id=${projectId}`);
        const result = await response.json();
        
        hideProgress();
        
        if (result.success) {
            currentProject = result.project;
            
            // ✅ 변경 추적 초기화
            changedRows.clear();
            
            return currentProject;
        } else {
            showToast('⚠️ ' + result.message);
            return null;
        }
    } catch (error) {
        hideProgress();
        console.error('프로젝트 로드 오류:', error);
        showToast('⚠️ 프로젝트 로드에 실패했습니다.');
        return null;
    }
}

// 프로젝트 삭제
async function deleteProjectData(projectId) {
    try {
        const response = await fetch(`${API_BASE_URL}/project_api.php?action=delete`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                pj_id: projectId
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showToast('✅ 프로젝트가 삭제되었습니다.');
            await loadProjects();
            
            // ✅ UI 업데이트
            if (typeof renderProjects === 'function') {
                renderProjects();
            }
            
            return true;
        } else {
            showToast('⚠️ ' + result.message);
            return false;
        }
    } catch (error) {
        console.error('프로젝트 삭제 오류:', error);
        showToast('⚠️ 프로젝트 삭제에 실패했습니다.');
        return false;
    }
}

// ✅ 셀 업데이트 (변경 추적 포함)
function updateCell(rowId, field, value) {
    const row = currentProject.data.find(r => r.id == rowId);
    if (row) {
        row[field] = value;
        
        // ✅ 변경된 행 ID 기록
        changedRows.add(rowId);
        
        console.log(`📝 변경: ${field} = ${value}, 변경된 행 수: ${changedRows.size}`);
        
        // ✅ 저장 버튼 활성화
        if (typeof window.debugSaveHandler?.markAsChanged === 'function') {
            window.debugSaveHandler.markAsChanged();
        }
        
        return true;
    }
    return false;
}

// ✅ 배치 저장 - 변경된 행만 전송 (최적화!)
async function batchSaveProject() {
    if (!currentProject) {
        console.warn('⚠️ currentProject가 없습니다');
        return false;
    }
    
    // ✅ 변경된 행이 없으면 저장 안 함
    if (changedRows.size === 0) {
        console.log('ℹ️ 변경된 데이터가 없습니다');
        showToast('ℹ️ 변경사항이 없습니다');
        return true;
    }
    
    try {
        showProgress();
        
        // ✅ 변경된 행만 필터링
        const changedData = currentProject.data.filter(row => 
            changedRows.has(row.id)
        );
        
        console.log(`💾 저장 시작: ${changedData.length}개 행 (전체 ${currentProject.data.length}개 중)`);
        
        const response = await fetch(`${API_BASE_URL}/data_api.php?action=batch_update`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                pj_id: currentProject.id,
                data: changedData  // ✅ 변경된 행만!
            })
        });
        
        const result = await response.json();
        
        hideProgress();
        
        if (result.success) {
            // ✅ 저장 성공 후 변경 추적 초기화
            changedRows.clear();
            
            showToast(`✅ ${result.count || changedData.length}개 행 저장 완료`);
            console.log('✅ 저장 성공');
            return true;
        } else {
            showToast('⚠️ ' + result.message);
            console.error('❌ 저장 실패:', result.message);
            return false;
        }
    } catch (error) {
        hideProgress();
        console.error('❌ 저장 오류:', error);
        showToast('⚠️ 저장에 실패했습니다.');
        return false;
    }
}

// ✅ 메모 추가
async function addMemoToRow(rowId, memoText) {
    try {
        const response = await fetch(`${API_BASE_URL}/data_api.php?action=add_memo`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                data_id: rowId,
                memo_text: memoText
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            // 로컬 데이터도 업데이트
            const row = currentProject.data.find(r => r.id == rowId);
            if (row) {
                row.메모 = result.memos;
            }
            showToast('✅ 메모가 추가되었습니다');
            return result.memos;
        } else {
            showToast('⚠️ ' + result.message);
            return null;
        }
    } catch (error) {
        console.error('메모 추가 오류:', error);
        showToast('⚠️ 메모 추가에 실패했습니다.');
        return null;
    }
}

// ========== 기존 함수들 (호환성 유지) ==========

// 붙여넣기 처리
function processPasteData(pastedText, rowIndex, field) {
    const rows = pastedText.split('\n').filter(row => row.trim() !== '');
    const fields = ['이름', '연락처', '주소'];
    const startFieldIndex = fields.indexOf(field);
    
    rows.forEach((row, i) => {
        const targetIndex = rowIndex + i;
        if (targetIndex < currentProject.data.length) {
            const cells = row.split('\t');
            const targetRow = currentProject.data[targetIndex];
            
            cells.forEach((cell, cellIndex) => {
                const targetField = fields[startFieldIndex + cellIndex];
                if (targetField && cell.trim() !== '') {
                    targetRow[targetField] = cell.trim();
                    
                    // ✅ 변경된 행 추적
                    changedRows.add(targetRow.id);
                }
            });
        }
    });
    
    console.log(`📋 붙여넣기: ${rows.length}개 행 변경됨, 총 변경: ${changedRows.size}개`);
    
    // ✅ 저장 버튼 활성화
    if (typeof window.debugSaveHandler?.markAsChanged === 'function') {
        window.debugSaveHandler.markAsChanged();
    }
}

// 날짜 포맷
function formatDate(date) {
    const d = new Date(date);
    return new Intl.DateTimeFormat('ko-KR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    }).format(d);
}

// 프로젝트 삭제 (UI)
function deleteProject(projectId) {
    const project = projects.find(p => p.id === projectId);
    if (!project) return;
    
    if (confirm(`"${project.projectName}" 프로젝트를 삭제하시겠습니까?\n\n삭제된 프로젝트는 복구할 수 없습니다.`)) {
        deleteProjectData(projectId).then(success => {
            if (success) {
                renderProjects();
            }
        });
    }
}

// ✅ 디버그 정보 출력
function getDebugInfo() {
    return {
        currentProject: currentProject?.projectName || 'None',
        totalRows: currentProject?.data.length || 0,
        changedRows: changedRows.size,
        changedRowIds: Array.from(changedRows)
    };
}

// 전역으로 노출 (디버깅용)
window.debugData = {
    changedRows,
    getDebugInfo,
    clearChanges: () => changedRows.clear()
};

console.log('✅ data.js 로드 완료 (최적화 버전 - 변경된 행만 저장)');
