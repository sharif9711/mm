<?php
// test_gnuboard.php - 그누보드 연결 테스트
// /html/map/api/test_gnuboard.php 에 업로드

header('Content-Type: application/json; charset=utf-8');

// 그누보드 설정 파일 포함
define('_GNUBOARD_', true);

// 경로를 여러 가지로 시도
$common_paths = [
    '../../common.php',
    '../../../common.php',
    '../../gnuboard/common.php',
    dirname(__FILE__) . '/../../common.php',
];

$common_loaded = false;
$tried_paths = [];

foreach ($common_paths as $path) {
    $tried_paths[] = $path;
    if (file_exists($path)) {
        include_once $path;
        $common_loaded = true;
        break;
    }
}

$result = [
    'common_loaded' => $common_loaded,
    'tried_paths' => $tried_paths,
    'is_member' => isset($is_member) ? $is_member : false,
    'member_info' => isset($member) ? [
        'mb_id' => $member['mb_id'] ?? 'N/A',
        'mb_name' => $member['mb_name'] ?? 'N/A'
    ] : null,
    'g5_vars' => [
        'G5_PATH' => defined('G5_PATH') ? G5_PATH : 'not defined',
        'G5_DATA_PATH' => defined('G5_DATA_PATH') ? G5_DATA_PATH : 'not defined'
    ],
    'current_dir' => __DIR__,
    'file_path' => __FILE__
];

echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
?>