<?php
// data_api.php - 최적화 버전

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, PUT, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// 이미 정의되어 있지 않을 때만 정의
if (!defined('_GNUBOARD_')) {
    define('_GNUBOARD_', true);
}

include_once '../../common.php';

if (!$is_member) {
    echo json_encode(['success' => false, 'message' => '로그인이 필요합니다.']);
    exit;
}

// ✅ GET과 POST 모두 지원
$action = $_GET['action'] ?? $_POST['action'] ?? '';
$input = json_decode(file_get_contents('php://input'), true);

try {
    switch ($action) {
        case 'batch_update':
            // ✅ 여러 행 일괄 업데이트 (변경된 행만)
            $pj_id = (int)($input['pj_id'] ?? 0);
            $updates = $input['data'] ?? [];
            
            if ($pj_id <= 0 || empty($updates)) {
                throw new Exception('잘못된 요청입니다.');
            }
            
            // 프로젝트 소유권 확인
            $check_sql = "SELECT pj_id FROM g5_map_projects 
                         WHERE pj_id = {$pj_id} AND mb_id = '{$member['mb_id']}'";
            $exists = sql_fetch($check_sql);
            
            if (!$exists) {
                throw new Exception('접근 권한이 없습니다.');
            }
            
            $success_count = 0;
            $error_count = 0;
            
            // ✅ 입력된 데이터만 필터링 (빈 행 제외)
            $validUpdates = array_filter($updates, function($item) {
                return !empty($item['이름']) || !empty($item['연락처']) || !empty($item['주소']);
            });
            
            error_log("📊 전체 {$pj_id}: 받은 행 " . count($updates) . "개, 유효 " . count($validUpdates) . "개");
            
            foreach ($validUpdates as $item) {
                $data_id = (int)($item['id'] ?? 0);
                if ($data_id <= 0) {
                    $error_count++;
                    continue;
                }
                
                $set_parts = [];
                
                // ✅ 업데이트할 필드들 (안전하게 처리)
                $string_fields = [
                    '이름', '연락처', '주소', '우편번호', '상태', 
                    '법정동코드', 'pnu코드', '대장구분', '본번', '부번', '지목', '면적', '기록사항'
                ];
                
                foreach ($string_fields as $field) {
                    if (isset($item[$field])) {
                        // ✅ XSS 방지: HTML 태그 제거
                        $value = strip_tags($item[$field]);
                        $value = sql_real_escape_string($value);
                        $set_parts[] = "`{$field}` = '{$value}'";
                    }
                }
                
                // ✅ 좌표 필드들 (숫자형)
                foreach (['lat', 'lng', 'vworld_lon', 'vworld_lat'] as $coord_field) {
                    if (isset($item[$coord_field])) {
                        if ($item[$coord_field] === null || $item[$coord_field] === '') {
                            $set_parts[] = "`{$coord_field}` = NULL";
                        } else {
                            $value = (float)$item[$coord_field];
                            $set_parts[] = "`{$coord_field}` = {$value}";
                        }
                    }
                }
                
                // ✅ 메모 필드 (JSON)
                if (isset($item['메모'])) {
                    if (is_array($item['메모'])) {
                        $memo_json = json_encode($item['메모'], JSON_UNESCAPED_UNICODE);
                    } else {
                        $memo_json = $item['메모'];
                    }
                    $memo_escaped = sql_real_escape_string($memo_json);
                    $set_parts[] = "`메모` = '{$memo_escaped}'";
                }
                
                if (!empty($set_parts)) {
                    try {
                        $update_sql = "UPDATE g5_map_data SET " . implode(', ', $set_parts) . 
                                      " WHERE data_id = {$data_id} AND pj_id = {$pj_id}";
                        sql_query($update_sql);
                        $success_count++;
                    } catch (Exception $e) {
                        error_log("❌ 행 업데이트 실패 (data_id: {$data_id}): " . $e->getMessage());
                        $error_count++;
                    }
                }
            }
            
            error_log("✅ 저장 완료: 성공 {$success_count}개, 실패 {$error_count}개");
            
            echo json_encode([
                'success' => true, 
                'message' => "{$success_count}개 행이 저장되었습니다.",
                'count' => $success_count,
                'errors' => $error_count
            ]);
            break;
            
        case 'add_memo':
            // 메모 추가
            $data_id = (int)($input['data_id'] ?? 0);
            $memo_text = strip_tags($input['memo_text'] ?? ''); // XSS 방지
            
            if ($data_id <= 0 || empty($memo_text)) {
                throw new Exception('잘못된 요청입니다.');
            }
            
            // 프로젝트 소유권 확인
            $check_sql = "SELECT d.메모 FROM g5_map_data d
                         INNER JOIN g5_map_projects p ON d.pj_id = p.pj_id
                         WHERE d.data_id = {$data_id} AND p.mb_id = '{$member['mb_id']}'";
            $row = sql_fetch($check_sql);
            
            if (!$row) {
                throw new Exception('접근 권한이 없습니다.');
            }
            
            // 기존 메모 가져오기
            $memos = json_decode($row['메모'], true) ?: [];
            
            // 새 메모 추가
            $now = date('Y.m.d H:i');
            $memos[] = [
                '내용' => $memo_text,
                '시간' => $now
            ];
            
            $memo_json = json_encode($memos, JSON_UNESCAPED_UNICODE);
            $memo_escaped = sql_real_escape_string($memo_json);
            
            $sql = "UPDATE g5_map_data SET 메모 = '{$memo_escaped}' WHERE data_id = {$data_id}";
            sql_query($sql);
            
            echo json_encode([
                'success' => true, 
                'message' => '메모가 추가되었습니다.', 
                'memos' => $memos
            ]);
            break;
            
        default:
            throw new Exception('잘못된 요청입니다.');
    }
    
} catch (Exception $e) {
    error_log("❌ API 오류: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
