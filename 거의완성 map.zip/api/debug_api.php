<?php
// debug_api.php - 에러 메시지 확인용
// /html/map/api/debug_api.php 에 업로드

// 에러 표시 활성화
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: text/html; charset=utf-8');

echo "<h1>🔍 API 디버그</h1>";
echo "<hr>";

// 1. PHP 버전
echo "<h2>1. PHP 버전</h2>";
echo "PHP Version: " . phpversion() . "<br>";
echo "<hr>";

// 2. 현재 디렉토리
echo "<h2>2. 현재 디렉토리</h2>";
echo "Current Directory: " . __DIR__ . "<br>";
echo "Document Root: " . $_SERVER['DOCUMENT_ROOT'] . "<br>";
echo "<hr>";

// 3. common.php 찾기
echo "<h2>3. common.php 경로 테스트</h2>";
$common_paths = [
    '../../common.php',
    '../../../common.php',
    dirname(__FILE__) . '/../../common.php',
    $_SERVER['DOCUMENT_ROOT'] . '/common.php',
    $_SERVER['DOCUMENT_ROOT'] . '/gnuboard/common.php',
];

foreach ($common_paths as $path) {
    $exists = file_exists($path);
    $status = $exists ? "✅ 존재" : "❌ 없음";
    $real_path = $exists ? realpath($path) : "N/A";
    echo "{$status} - {$path}<br>";
    if ($exists) {
        echo "→ 실제 경로: {$real_path}<br>";
    }
    echo "<br>";
}
echo "<hr>";

// 4. 그누보드 로드 시도
echo "<h2>4. 그누보드 로드 시도</h2>";
define('_GNUBOARD_', true);

$loaded = false;
$load_path = '';

foreach ($common_paths as $path) {
    if (file_exists($path)) {
        try {
            include_once $path;
            $loaded = true;
            $load_path = $path;
            echo "✅ 성공: {$path}<br>";
            break;
        } catch (Exception $e) {
            echo "❌ 실패: {$path}<br>";
            echo "에러: " . $e->getMessage() . "<br><br>";
        }
    }
}

if ($loaded) {
    echo "<br><strong>✅ 그누보드 로드 성공!</strong><br>";
    echo "로드된 경로: {$load_path}<br>";
} else {
    echo "<br><strong>❌ 그누보드 로드 실패</strong><br>";
    echo "common.php를 찾을 수 없습니다.<br>";
}
echo "<hr>";

// 5. 로그인 상태
echo "<h2>5. 로그인 상태</h2>";
if ($loaded) {
    echo "is_member: " . (isset($is_member) ? ($is_member ? 'true' : 'false') : 'undefined') . "<br>";
    if (isset($member) && $is_member) {
        echo "회원 ID: " . $member['mb_id'] . "<br>";
        echo "회원 이름: " . $member['mb_name'] . "<br>";
    } else {
        echo "⚠️ 로그인되지 않음<br>";
    }
} else {
    echo "그누보드가 로드되지 않아 확인 불가<br>";
}
echo "<hr>";

// 6. 데이터베이스 연결
echo "<h2>6. 데이터베이스 연결</h2>";
if ($loaded && function_exists('sql_query')) {
    try {
        $result = sql_query("SHOW TABLES LIKE 'g5_map%'");
        $tables = [];
        while ($row = sql_fetch_array($result)) {
            $tables[] = $row[0];
        }
        
        if (count($tables) > 0) {
            echo "✅ 데이터베이스 연결 성공<br>";
            echo "찾은 테이블:<br>";
            foreach ($tables as $table) {
                echo "- {$table}<br>";
            }
        } else {
            echo "⚠️ 연결은 되나 g5_map 테이블이 없음<br>";
            echo "install_tables.sql을 실행하세요.<br>";
        }
    } catch (Exception $e) {
        echo "❌ 데이터베이스 오류<br>";
        echo "에러: " . $e->getMessage() . "<br>";
    }
} else {
    echo "그누보드가 로드되지 않아 확인 불가<br>";
}
echo "<hr>";

// 7. 결론
echo "<h2>7. 결론</h2>";
if ($loaded && isset($is_member) && $is_member && function_exists('sql_query')) {
    echo "<strong style='color: green; font-size: 18px;'>✅ 모든 테스트 통과! API 사용 가능</strong><br>";
    echo "<br>다음 단계: project_api.php를 테스트하세요.<br>";
} else {
    echo "<strong style='color: red; font-size: 18px;'>❌ 문제 발견</strong><br><br>";
    
    if (!$loaded) {
        echo "⚠️ <strong>common.php를 찾을 수 없습니다.</strong><br>";
        echo "→ 그누보드 설치 경로를 확인하세요.<br><br>";
    }
    
    if ($loaded && (!isset($is_member) || !$is_member)) {
        echo "⚠️ <strong>로그인되지 않았습니다.</strong><br>";
        echo "→ 그누보드에 로그인 후 다시 시도하세요.<br><br>";
    }
    
    if ($loaded && !function_exists('sql_query')) {
        echo "⚠️ <strong>데이터베이스 함수가 없습니다.</strong><br>";
        echo "→ 그누보드가 제대로 설치되지 않았을 수 있습니다.<br><br>";
    }
}
?>