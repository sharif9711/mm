<?php
// test_api.php - API 연결 테스트
// /html/map/api/test_api.php 에 업로드

header('Content-Type: application/json; charset=utf-8');

echo json_encode([
    'test' => 'success',
    'php_version' => phpversion(),
    'server_time' => date('Y-m-d H:i:s'),
    'get_params' => $_GET,
    'post_params' => $_POST
]);
?>