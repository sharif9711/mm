<?php
// project_api.php - Warning 수정 버전

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// ✅ 이미 정의되어 있지 않을 때만 정의
if (!defined('_GNUBOARD_')) {
    define('_GNUBOARD_', true);
}

// 그누보드 설정 파일 포함
include_once '../../common.php';

// 로그인 체크
if (!$is_member) {
    echo json_encode(['success' => false, 'message' => '로그인이 필요합니다.']);
    exit;
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

try {
    switch ($action) {
        case 'list':
            // 프로젝트 목록 조회
            $sql = "SELECT pj_id, pj_name, map_type, created_at, updated_at 
                    FROM g5_map_projects 
                    WHERE mb_id = '{$member['mb_id']}' 
                    ORDER BY created_at DESC";
            $result = sql_query($sql);
            
            $projects = [];
            while ($row = sql_fetch_array($result)) {
                // 각 프로젝트의 데이터 개수 조회
                $count_sql = "SELECT COUNT(*) as cnt FROM g5_map_data WHERE pj_id = {$row['pj_id']}";
                $count_result = sql_fetch($count_sql);
                
                $projects[] = [
                    'id' => (string)$row['pj_id'],
                    'projectName' => $row['pj_name'],
                    'mapType' => $row['map_type'],
                    'createdAt' => $row['created_at'],
                    'updatedAt' => $row['updated_at'],
                    'dataCount' => $count_result['cnt']
                ];
            }
            
            echo json_encode(['success' => true, 'projects' => $projects]);
            break;
            
        case 'create':
            // 프로젝트 생성
            $input = json_decode(file_get_contents('php://input'), true);
            $pj_name = sql_real_escape_string($input['projectName'] ?? '');
            $map_type = sql_real_escape_string($input['mapType'] ?? 'vworld');
            
            if (empty($pj_name)) {
                throw new Exception('프로젝트 이름을 입력해주세요.');
            }
            
            $sql = "INSERT INTO g5_map_projects (mb_id, pj_name, map_type) 
                    VALUES ('{$member['mb_id']}', '{$pj_name}', '{$map_type}')";
            sql_query($sql);
            
            $pj_id = sql_insert_id();
            
            // 초기 1500행 데이터 생성
            $values = [];
            for ($i = 1; $i <= 1500; $i++) {
                $values[] = "({$pj_id}, {$i}, '', '', '', '', NULL, NULL, NULL, NULL, '예정', '', '', '', '', '', '', '', '', '[]')";
            }
            
            // 한 번에 삽입 (배치 처리)
            $batch_size = 100;
            $batches = array_chunk($values, $batch_size);
            
            foreach ($batches as $batch) {
                $insert_sql = "INSERT INTO g5_map_data 
                              (pj_id, 순번, 이름, 연락처, 주소, 우편번호, lat, lng, vworld_lon, vworld_lat, 
                               상태, 법정동코드, pnu코드, 대장구분, 본번, 부번, 지목, 면적, 기록사항, 메모) 
                              VALUES " . implode(', ', $batch);
                sql_query($insert_sql);
            }
            
            echo json_encode([
                'success' => true, 
                'message' => '프로젝트가 생성되었습니다.',
                'projectId' => (string)$pj_id
            ]);
            break;
            
        case 'get':
            // 프로젝트 상세 조회
            $pj_id = (int)($_GET['pj_id'] ?? 0);
            
            if ($pj_id <= 0) {
                throw new Exception('잘못된 프로젝트 ID입니다.');
            }
            
            // 프로젝트 소유권 확인
            $check_sql = "SELECT * FROM g5_map_projects 
                         WHERE pj_id = {$pj_id} AND mb_id = '{$member['mb_id']}'";
            $project = sql_fetch($check_sql);
            
            if (!$project) {
                throw new Exception('프로젝트를 찾을 수 없거나 접근 권한이 없습니다.');
            }
            
            // 프로젝트 데이터 조회
            $data_sql = "SELECT * FROM g5_map_data WHERE pj_id = {$pj_id} ORDER BY 순번 ASC";
            $data_result = sql_query($data_sql);
            
            $data = [];
            while ($row = sql_fetch_array($data_result)) {
                $data[] = [
                    'id' => $row['data_id'],
                    '순번' => (int)$row['순번'],
                    '이름' => $row['이름'],
                    '연락처' => $row['연락처'],
                    '주소' => $row['주소'],
                    '우편번호' => $row['우편번호'],
                    'lat' => $row['lat'] ? (float)$row['lat'] : null,
                    'lng' => $row['lng'] ? (float)$row['lng'] : null,
                    'vworld_lon' => $row['vworld_lon'] ? (float)$row['vworld_lon'] : null,
                    'vworld_lat' => $row['vworld_lat'] ? (float)$row['vworld_lat'] : null,
                    '상태' => $row['상태'],
                    '법정동코드' => $row['법정동코드'],
                    'pnu코드' => $row['pnu코드'],
                    '대장구분' => $row['대장구분'],
                    '본번' => $row['본번'],
                    '부번' => $row['부번'],
                    '지목' => $row['지목'],
                    '면적' => $row['면적'],
                    '기록사항' => $row['기록사항'],
                    '메모' => json_decode($row['메모'], true) ?: []
                ];
            }
            
            echo json_encode([
                'success' => true,
                'project' => [
                    'id' => (string)$project['pj_id'],
                    'projectName' => $project['pj_name'],
                    'mapType' => $project['map_type'],
                    'createdAt' => $project['created_at'],
                    'data' => $data
                ]
            ]);
            break;
            
        case 'delete':
            // 프로젝트 삭제
            $input = json_decode(file_get_contents('php://input'), true);
            $pj_id = (int)($input['pj_id'] ?? 0);
            
            if ($pj_id <= 0) {
                throw new Exception('잘못된 프로젝트 ID입니다.');
            }
            
            // 소유권 확인
            $check_sql = "SELECT pj_id FROM g5_map_projects 
                         WHERE pj_id = {$pj_id} AND mb_id = '{$member['mb_id']}'";
            $exists = sql_fetch($check_sql);
            
            if (!$exists) {
                throw new Exception('프로젝트를 찾을 수 없거나 삭제 권한이 없습니다.');
            }
            
            // CASCADE로 연결된 데이터도 자동 삭제됨
            $sql = "DELETE FROM g5_map_projects WHERE pj_id = {$pj_id}";
            sql_query($sql);
            
            echo json_encode(['success' => true, 'message' => '프로젝트가 삭제되었습니다.']);
            break;
            
        default:
            throw new Exception('잘못된 요청입니다.');
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>