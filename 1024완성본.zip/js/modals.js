// modals.js - 모달 관련 함수 (DB 연동 버전)

function openCreateModal() {
    document.getElementById('createModal').classList.add('active');
}

function closeCreateModal() {
    document.getElementById('createModal').classList.remove('active');
    document.getElementById('projectName').value = '';
    // VWorld를 기본값으로 체크
    document.getElementById('mapTypeVworld').checked = true;
}

async function createProject() {
    const name = document.getElementById('projectName').value;
    const mapType = document.querySelector('input[name="mapType"]:checked').value;

    if (!name) {
        alert('프로젝트 이름을 입력해주세요.');
        return;
    }

    showProgress();
    
    const projectId = await createProjectData(name, mapType);
    
    hideProgress();
    
    if (projectId) {
        closeCreateModal();
        await loadProjects();
        if (typeof renderProjects === 'function') {
            renderProjects();
        }
    }
}

// 프로젝트를 바로 여는 함수 (DB에서 로드)
async function openProjectDirectly(projectId) {
    showProgress();
    
    const project = await loadProjectDetail(projectId);
    
    hideProgress();
    
    if (project) {
        currentProject = project;
        if (typeof showProjectDetail === 'function') {
            showProjectDetail();
        } else {
            console.error('showProjectDetail function is not defined');
            alert('프로젝트를 열 수 없습니다. 페이지를 새로고침해주세요.');
        }
    } else {
        alert('프로젝트를 불러올 수 없습니다.');
    }
}