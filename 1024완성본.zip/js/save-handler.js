// save-handler.js - 최종 수정 버전

console.log("✅ js/save-handler.js loaded successfully.");

// 저장 상태 추적
let hasUnsavedChanges = false;
let autoSaveTimer = null;

// 변경사항 표시
function markAsChanged() {
    console.log('🔄 변경사항 감지');
    hasUnsavedChanges = true;
    
    // 저장 버튼 활성화
    const saveBtn = document.getElementById('manualSaveBtn');
    if (saveBtn) {
        saveBtn.disabled = false;
        saveBtn.classList.remove('opacity-50', 'cursor-not-allowed', 'bg-slate-400');
        saveBtn.classList.add('hover:bg-green-700', 'bg-green-600');
    }
    
    // 3초 후 자동 저장
    if (autoSaveTimer) clearTimeout(autoSaveTimer);
    autoSaveTimer = setTimeout(() => {
        console.log('⏰ 3초 경과 - 자동 저장 시작');
        autoSaveToServer();
    }, 3000);
}

// 자동 저장
async function autoSaveToServer() {
    if (!currentProject) {
        console.warn('⚠️ currentProject가 없습니다');
        return;
    }
    
    if (!hasUnsavedChanges) {
        console.log('ℹ️ 저장할 변경사항이 없습니다');
        return;
    }
    
    console.log('💾 자동 저장 시작...');
    
    if (typeof batchSaveProject !== 'function') {
        console.error('❌ batchSaveProject 함수가 없습니다!');
        showToast('❌ 저장 함수 오류');
        return;
    }
    
    const success = await batchSaveProject();
    
    if (success) {
        hasUnsavedChanges = false;
        const saveBtn = document.getElementById('manualSaveBtn');
        if (saveBtn) {
            saveBtn.disabled = true;
            saveBtn.classList.add('opacity-50', 'cursor-not-allowed', 'bg-slate-400');
            saveBtn.classList.remove('hover:bg-green-700', 'bg-green-600');
        }
        console.log('✅ 자동 저장 완료');
        showToast('✅ 자동 저장 완료');
    } else {
        console.error('❌ 자동 저장 실패');
        showToast('⚠️ 자동 저장 실패');
    }
}

// 수동 저장
async function manualSaveToServer() {
    console.log('👆 수동 저장 버튼 클릭');
    
    if (!currentProject) {
        showToast('⚠️ 프로젝트가 없습니다');
        return;
    }
    
    const saveBtn = document.getElementById('manualSaveBtn');
    if (saveBtn) {
        saveBtn.disabled = true;
        const originalHTML = saveBtn.innerHTML;
        saveBtn.innerHTML = '<span class="animate-spin">⏳</span> 저장 중...';
    }
    
    if (typeof batchSaveProject !== 'function') {
        console.error('❌ batchSaveProject 함수가 없습니다!');
        showToast('❌ 저장 함수 오류');
        if (saveBtn) {
            saveBtn.innerHTML = originalHTML;
            saveBtn.disabled = false;
        }
        return;
    }
    
    const success = await batchSaveProject();
    
    if (saveBtn) {
        saveBtn.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
                <polyline points="17 21 17 13 7 13 7 21"></polyline>
                <polyline points="7 3 7 8 15 8"></polyline>
            </svg>
            저장
        `;
        
        if (success) {
            hasUnsavedChanges = false;
            saveBtn.classList.add('opacity-50', 'cursor-not-allowed', 'bg-slate-400');
            saveBtn.classList.remove('hover:bg-green-700', 'bg-green-600');
            console.log('✅ 수동 저장 완료');
            showToast('✅ 저장 완료');
        } else {
            saveBtn.disabled = false;
            saveBtn.classList.add('bg-green-600', 'hover:bg-green-700');
            saveBtn.classList.remove('bg-slate-400');
            console.error('❌ 수동 저장 실패');
        }
    }
}

// 이벤트 위임 방식으로 변경 감지
function attachEventDelegation() {
    console.log('🎧 이벤트 위임 설정 시작');
    
    // ✅ 이미 설정되어 있으면 스킵하지 않고 재확인
    if (window._saveHandlerAttached) {
        console.log('ℹ️ 이벤트 위임이 이미 설정됨 - 재확인');
    }
    
    // 자료입력 테이블
    const dataInputTable = document.getElementById('dataInputTable');
    if (dataInputTable && !dataInputTable._hasInputListener) {
        dataInputTable.addEventListener('input', function(e) {
            if (e.target.tagName === 'INPUT') {
                console.log('✏️ 자료입력 변경:', e.target.value);
                markAsChanged();
            }
        }, true);
        
        dataInputTable.addEventListener('change', function(e) {
            if (e.target.tagName === 'INPUT') {
                console.log('✏️ 자료입력 변경 (change):', e.target.value);
                markAsChanged();
            }
        }, true);
        
        dataInputTable._hasInputListener = true;
        console.log('✅ 자료입력 테이블 이벤트 설정 완료');
    } else if (dataInputTable) {
        console.log('ℹ️ 자료입력 테이블 이벤트 이미 설정됨');
    } else {
        console.warn('⚠️ 자료입력 테이블을 찾을 수 없음');
    }
    
    // 보고서 테이블
    const reportTable = document.getElementById('reportTable');
    if (reportTable && !reportTable._hasChangeListener) {
        // SELECT 변경 감지
        reportTable.addEventListener('change', function(e) {
            if (e.target.tagName === 'SELECT') {
                console.log('📝 보고서 SELECT 변경:', e.target.value);
                markAsChanged();
            }
        }, true);
        
        // INPUT 변경 감지 (메모 등)
        reportTable.addEventListener('input', function(e) {
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                console.log('📝 보고서 INPUT 변경:', e.target.value);
                markAsChanged();
            }
        }, true);
        
        reportTable._hasChangeListener = true;
        console.log('✅ 보고서 테이블 이벤트 설정 완료 (SELECT + INPUT)');
    } else if (reportTable) {
        console.log('ℹ️ 보고서 테이블 이벤트 이미 설정됨');
    } else {
        console.warn('⚠️ 보고서 테이블을 찾을 수 없음');
    }
    
    window._saveHandlerAttached = true;
    console.log('✅ 이벤트 위임 설정 완료');
}

// 저장 버튼 추가
function addSaveButton() {
    console.log('🔘 저장 버튼 추가 시도');
    
    const checkAndAdd = () => {
        const header = document.querySelector('#projectDetailScreen.active header .flex.items-center.justify-between');
        
        if (!header) {
            return false;
        }
        
        if (document.getElementById('manualSaveBtn')) {
            // ✅ 이미 버튼이 있어도 이벤트는 다시 등록
            if (!window._saveHandlerAttached) {
                console.log('🔄 이벤트 리스너 재등록');
                attachEventDelegation();
            }
            return true;
        }
        
        const saveBtn = document.createElement('button');
        saveBtn.id = 'manualSaveBtn';
        saveBtn.className = 'px-4 py-2 bg-slate-400 text-white rounded-lg opacity-50 cursor-not-allowed transition-colors text-sm flex items-center gap-2';
        saveBtn.disabled = true;
        saveBtn.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
                <polyline points="17 21 17 13 7 13 7 21"></polyline>
                <polyline points="7 3 7 8 15 8"></polyline>
            </svg>
            저장
        `;
        saveBtn.onclick = manualSaveToServer;
        
        const mapBtn = document.getElementById('mapViewButton');
        if (mapBtn) {
            header.insertBefore(saveBtn, mapBtn);
            console.log('✅ 저장 버튼 추가 완료');
        } else {
            header.appendChild(saveBtn);
            console.log('✅ 저장 버튼 추가 완료 (헤더 끝)');
        }
        
        // ✅ 이벤트 리스너 등록
        attachEventDelegation();
        
        return true;
    };
    
    if (checkAndAdd()) {
        return;
    }
    
    const observer = new MutationObserver((mutations) => {
        if (checkAndAdd()) {
            observer.disconnect();
        }
    });
    
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
}

// ✅ backToList 오버라이드 (강화 버전)
const originalBackToList = window.backToList;
if (typeof originalBackToList === 'function') {
    window.backToList = function() {
        console.log('🚪 backToList 호출됨');
        console.log('hasUnsavedChanges:', hasUnsavedChanges);
        console.log('changedRows:', window.debugData?.changedRows?.size);
        
        // ✅ 변경사항 확인 (두 가지 조건 모두 체크)
        const hasChanges = hasUnsavedChanges || (window.debugData?.changedRows?.size > 0);
        
        if (hasChanges) {
            console.log('⚠️ 저장되지 않은 변경사항 있음 - 경고 표시');
            
            if (!confirm('저장되지 않은 변경사항이 있습니다.\n나가시겠습니까?')) {
                console.log('✋ 사용자가 취소함');
                return;
            }
            console.log('✅ 사용자가 확인함 - 나가기');
        }
        
        // 상태 초기화
        hasUnsavedChanges = false;
        if (window.debugData?.changedRows) {
            window.debugData.changedRows.clear();
        }
        window._saveHandlerAttached = false;
        
        // 원래 함수 호출
        originalBackToList();
    };
    console.log('✅ backToList 오버라이드 완료 (강화)');
} else {
    console.error('⚠️ backToList 함수를 찾을 수 없습니다!');
}

// ✅ 페이지 나가기 전 경고
window.addEventListener('beforeunload', function(e) {
    const hasChanges = hasUnsavedChanges || (window.debugData?.changedRows?.size > 0);
    
    if (hasChanges && currentProject) {
        console.log('⚠️ 저장되지 않은 변경사항 - 페이지 나가기 경고');
        e.preventDefault();
        e.returnValue = '';
        return '';
    }
});

// 초기화
function init() {
    console.log('🚀 save-handler.js 초기화');
    addSaveButton();
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}

// 전역 함수 노출
window.debugSaveHandler = {
    markAsChanged,
    autoSaveToServer,
    manualSaveToServer,
    hasUnsavedChanges: () => hasUnsavedChanges,
    attachEventDelegation
};

console.log('🔧 save-handler.js 로드 완료 (최종 버전)');
